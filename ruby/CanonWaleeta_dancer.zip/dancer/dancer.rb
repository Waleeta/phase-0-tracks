class Dancer
	attr_reader :name, :card
	attr_accessor :age


	def initialize(name, age)
		@name = name
		@age = age
		@card = []
	end 

	def pirouette
		p "*twirls*"
	end 

	def bow
		p "*bows*"
	end

	def queue_dance_with(dancer_name)
		@card << dancer_name
		@card
	end 

	def begin_next_dance
		p "Now dancing with #{@card.shift}."
	end 

	#This method is meant to test a boolean condition - if dancer dances too long she's too tired to continue.
		#Otherwise she continues to dance.
	def dance_time(minutes)
		if minutes >= 20 
			p "I'm too tired to dance anymore, it's been #{minutes} minutes."
		else 
			p "It's only been #{minutes} minutes, I can go on!"
		end 
	end
	
end 

#dancer = Dancer.new("Misty Copeland", 33)

