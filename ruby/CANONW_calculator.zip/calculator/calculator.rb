#PLEASE IGNORE THE RSPEC IN THIS FOLDER (I DON'T WANT TO MOVE OR DELETER IT, IT IS FOR 
    #A DIFFERENT PROJECT)

  def calculate(num1, op, num2)
    if op == "+"
    	num1 + num2
    elsif op == "-"
    	num1 - num2
    elsif op == "/"
    	num1/num2
    elsif op == "*"
    	num1*num2
    else
    	puts "That's not a valid operator, please give me: *, /, +, or -: "
    	op = gets.chomp 
    end
  end
  
responses = {}

puts "Press enter or 'done': "
	answer = gets.chomp.downcase 

until answer == "done"
	puts "Please give me a number: "
	num1 = gets.chomp.to_i
		
	puts "Please give me another number: "
	num2 = gets.chomp.to_i

	puts "Now, what would you like to do: +, -, /, or *: "
	op = gets.chomp 
		
	responses["#{num1} #{op} #{num2}"] = calculate(num1, op, num2)

	puts "'Enter' to continue, or 'done': "
	answer = gets.chomp.downcase
end 

p "#{responses.length} calculation(s) performed."

responses.map do |equation, result|
	puts "#{equation} = #{result}"
end 




#calculate(num1, op, num2)



#DRIVER CODE

# p calculate(30, "+", 20)
# p calculate(30, "-", 20)
# p calculate(30, "/", 3)
# p calculate(30, "*", 20)
# p calculate(30, "%", 20)